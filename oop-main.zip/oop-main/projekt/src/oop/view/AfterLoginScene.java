package oop.view;

public class AfterLoginScene {
}
