package oop.model.program;

public class Model {
}
