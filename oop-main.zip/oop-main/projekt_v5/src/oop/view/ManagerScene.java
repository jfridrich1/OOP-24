package oop.view;

public class ManagerScene {
}
