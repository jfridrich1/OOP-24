package oop.controller;

public class ManagerController {
}
