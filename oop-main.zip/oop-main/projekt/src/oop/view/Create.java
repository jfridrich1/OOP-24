package oop.view;

public class Create {
}
